import enum
from pathlib import Path
from typing import Optional


class RobotName(enum.Enum):
    o7 = enum.auto()
    l7 = enum.auto()
    l10 = enum.auto()
    l20 = enum.auto()
    l18 = enum.auto()
    l16 = enum.auto()
    t25 = enum.auto()
    l25 = enum.auto()
    l21 = enum.auto()
    l30 = enum.auto()


class RetargetingType(enum.Enum):
    vector = enum.auto()  # For teleoperation, no finger closing prior
    position = enum.auto()  # For offline data processing, especially hand-object interaction data
    dexpilot = enum.auto()  # For teleoperation, with finger closing prior
    projection = enum.auto()


class HandType(enum.Enum):
    right = enum.auto()
    left = enum.auto()


class DataSource(enum.Enum):
    motion = enum.auto()
    video = enum.auto()
    vr = enum.auto()


class MotionSource(enum.Enum):
    vtrdyn = enum.auto()
    udexreal = enum.auto()
    udexrealv2t = enum.auto()
    linkerforce = enum.auto()
    sensenova = enum.auto()


ROBOT_NAME_MAP = {
    RobotName.o7: "linker_hand_o7",
    RobotName.l7: "linker_hand_l7",
    RobotName.l10: "linker_hand_l10",
    RobotName.l20: "linker_hand_l20",
    RobotName.l18: "linker_hand_l18",
    RobotName.l16: "linker_hand_l16",
    RobotName.t25: "linker_hand_t25",
    RobotName.l25: "linker_hand_l25",
    RobotName.l21: "linker_hand_l21",
    RobotName.l30: "linker_hand_l30",
}

ROBOT_NAMES = list(ROBOT_NAME_MAP.keys())


ROBOT_LEN_MAP ={
    RobotName.o7: 7,
    RobotName.l7: 7,
    RobotName.l10: 10,
    RobotName.l20: 20,
    RobotName.l18: 25,
    RobotName.l16: 25,
    RobotName.t25: 25,
    RobotName.l25: 25,
    RobotName.l21: 25,
    RobotName.l30: 17,
}

ROBOT_LEN = list(ROBOT_LEN_MAP.keys())


def get_default_config_path(
        robot_name: RobotName, retargeting_type: RetargetingType, hand_type: HandType
) -> Optional[Path]:
    config_path = Path(__file__).parent / "configs"
    if retargeting_type is RetargetingType.position:
        config_path = config_path / "offline"
    else:
        config_path = config_path / "teleop"

    robot_name_str = ROBOT_NAME_MAP[robot_name]
    hand_type_str = hand_type.name
    if "gripper" in robot_name_str:  # For gripper robots, only use gripper config file.
        if retargeting_type == RetargetingType.dexpilot:
            config_name = f"{robot_name_str}_dexpilot.yml"
        else:
            config_name = f"{robot_name_str}.yml"
    else:
        if retargeting_type == RetargetingType.dexpilot:
            config_name = f"{robot_name_str}_{hand_type_str}_dexpilot.yml"
        else:
            config_name = f"{robot_name_str}_{hand_type_str}.yml"
    return config_path / config_name
