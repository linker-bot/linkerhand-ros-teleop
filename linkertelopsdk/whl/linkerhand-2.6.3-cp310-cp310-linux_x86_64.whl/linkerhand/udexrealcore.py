from datetime import datetime
import socket
import numpy as np
import time
from threading import Thread
import json
from dataclasses import dataclass
from typing import List, Dict, Union, Any
import threading


NODES_HAND = 24


@dataclass
class Bone:
    Name: str
    Parent: int
    Location: List[float]
    Rotation: List[float]
    Scale: List[float]


@dataclass
class Parameter:
    Name: str
    Value: Union[float, int, bool]


@dataclass
class DeviceData:
    Bones: List[Bone]
    Parameter: List[Parameter]


class MotionData:
    def __init__(self, raw_data: Dict[str, Any]):
        """
        动态处理顶层键名（如eric或其他设备ID）
        """
        self.devices = {}
        for device_id, device_content in raw_data.items():
            bones = [Bone(**bone) for bone in device_content["Bones"]]
            parameters = [Parameter(**param) for param in device_content["Parameter"]]
            self.devices[device_id] = DeviceData(Bones=bones, Parameter=parameters)

    def get_device(self, device_id: str) -> DeviceData:
        """获取指定设备的数据"""
        return self.devices.get(device_id)

    def get_all_device_ids(self) -> List[str]:
        """获取所有设备ID"""
        return list(self.devices.keys())

    def get_parameter_value(self, device_id: str, param_name: str) -> Union[float, int, bool]:
        """获取指定设备的参数值"""
        device = self.get_device(device_id)
        if not device:
            raise ValueError(f"Device {device_id} not found")

        for param in device.Parameter:
            if param.Name == param_name:
                return param.Value
        raise ValueError(f"Parameter {param_name} not found in device {device_id}")

    def list_sequence_params(self, device_id: str, prefix: str) -> Dict[str, Union[float, int, bool]]:
        """获取指定设备的所有序列参数"""
        device = self.get_device(device_id)
        if not device:
            raise ValueError(f"Device {device_id} not found")

        return {
            param.Name: param.Value
            for param in device.Parameter
            if param.Name.startswith(prefix) and param.Name[len(prefix):].isdigit()
        }


class UdexRealSData:
    def __init__(self):
        self.is_update = False
        self.frame_index = 0
        self.frequency = 0
        self.ns_result = 0
        self.jointangle_rHand = [0.0] * NODES_HAND
        self.jointangle_lHand = [0.0] * NODES_HAND


class UdexRealScoketUdp:
    def __init__(self, host='0.0.0.0', port=7000, buffer_size=2048, device_id='eric'):
        self.socket_udp = None
        self.is_use_face_blend_shapes_arkit = False
        self.udp_thread = None
        self.udp_running = False
        self.isconnect = False
        self.host = host
        self.port = port
        self.device_id = device_id
        self.buffer_size = buffer_size
        self.realmocapdata = UdexRealSData()
        self.data_lock = threading.Lock()

    def udp_initial(self) -> bool:
        """初始化 UDP socket"""
        try:
            self.socket_udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.socket_udp.bind(('', self.port))
            self.socket_udp.settimeout(10)
            self.isconnect = True
            self.udp_running = True
            self.udp_thread = Thread(target=self.__udp_process)
            self.udp_thread.start()
            return True
        except socket.error as e:
            self.isconnect = False
            print(f"发生错误: {e},UDP套接字已关闭!")
            if self.socket_udp:
                self.socket_udp.close()
            return False

    def __recv(self) -> tuple:
        try:
            data, addr = self.socket_udp.recvfrom(self.buffer_size)
            return data, addr
        except socket.timeout:
            return None, None

    def udp_close(self) -> bool:
        self.udp_running = False
        self.udp_thread.join()
        time.sleep(0.1)
        if self.socket_udp:
            self.socket_udp.close()
        return True

    def udp_is_onnect(self) -> bool:
        return self.isconnect

    def __udp_process(self):
        errorprintcount = 0
        while self.udp_running:
            try:
                bytes_data, addr = self.__recv()
                if bytes_data is not None:
                    try:
                        json_data = json.loads(bytes_data.decode('utf-8'))
                        with self.data_lock:
                            motion_data = MotionData(json_data)
                            device_id = self.device_id
                            self.realmocapdata.is_update = True
                            l_params = motion_data.list_sequence_params(device_id, "l")
                            for name, value in sorted(l_params.items(), key=lambda x: int(x[0][1:])):
                                self.realmocapdata.jointangle_lHand [int(name[1:])] = np.deg2rad(value)
                            r_params = motion_data.list_sequence_params(device_id, "r")
                            for name, value in sorted(r_params.items(), key=lambda x: int(x[0][1:])):
                                self.realmocapdata.jointangle_rHand[int(name[1:])] = np.deg2rad(value)
                    except json.JSONDecodeError as e:
                        if errorprintcount > 100:
                            print(f"JSON解析错误: {e}")
                            print(f"原始数据: {bytes_data.decode('utf-8', errors='replace')}")
                            errorprintcount = 0
                    except ValueError as e:  # 新增：捕获 ValueError
                        if errorprintcount > 100:
                            print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 设备ID错误: {e}")
                            errorprintcount = 0
            except Exception as e:
                print(f"未知错误: {e}")
            finally:
                errorprintcount += 1
                time.sleep(0.001)

    def udp_recv_mocap_data(self, mocap_data: UdexRealSData) -> bool:
        with self.data_lock:
            mocap_data.frame_index = self.realmocapdata.frame_index
            mocap_data.is_update = self.realmocapdata.is_update
            mocap_data.frequency = self.realmocapdata.frequency
            mocap_data.jointangle_rHand = self.realmocapdata.jointangle_rHand
            mocap_data.jointangle_lHand = self.realmocapdata.jointangle_lHand
        return True
